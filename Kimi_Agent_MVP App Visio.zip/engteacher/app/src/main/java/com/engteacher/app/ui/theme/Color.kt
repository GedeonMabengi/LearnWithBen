package com.engteacher.app.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF1E3A5F)
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFFD4E3F7)
val OnPrimaryContainer = Color(0xFF0A2540)

val Secondary = Color(0xFF4A6FA5)
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFD0DEF0)
val OnSecondaryContainer = Color(0xFF1A2D4A)

val Tertiary = Color(0xFF6B8CAE)
val OnTertiary = Color(0xFFFFFFFF)

val Surface = Color(0xFFF8F9FC)
val OnSurface = Color(0xFF1E1E2C)
val SurfaceVariant = Color(0xFFE2E8F0)
val OnSurfaceVariant = Color(0xFF4A5568)

val Background = Color(0xFFF0F4F8)
val OnBackground = Color(0xFF1E1E2C)

val Error = Color(0xFFC53030)
val OnError = Color(0xFFFFFFFF)
val ErrorContainer = Color(0xFFFED7D7)
val OnErrorContainer = Color(0xFF742A2A)

val Success = Color(0xFF276749)
val OnSuccess = Color(0xFFFFFFFF)
val SuccessContainer = Color(0xFFC6F6D5)
val OnSuccessContainer = Color(0xFF22543D)

val Warning = Color(0xFFC05621)
val OnWarning = Color(0xFFFFFFFF)
val WarningContainer = Color(0xFFFEEBC8)
val OnWarningContainer = Color(0xFF7B341E)

val Outline = Color(0xFFA0AEC0)
val OutlineVariant = Color(0xFFCBD5E0)

val Scrim = Color(0x80000000)
